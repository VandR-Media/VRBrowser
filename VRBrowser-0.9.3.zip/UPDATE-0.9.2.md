# V&R Browser 0.9.2

- Downloads display the real filename with its extension (including .ts).
- Fixed GitHub Actions APK version metadata verification to expect 0.9.2 / 902.
- Preserved existing HLS downloader, branding, and launcher icons.

Note: debug APK signing may differ between builds; uninstall before installing if signature mismatch occurs. Persistent release signing requires GitHub secrets.
