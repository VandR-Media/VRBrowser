package com.vrbrowser.app

import android.app.*
import android.os.*
import android.content.*
import android.graphics.Color
import android.view.*
import android.webkit.*
import android.widget.*
import android.text.InputType
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

class MainActivity : Activity() {
 private lateinit var root: LinearLayout
 private lateinit var address: EditText
 private lateinit var pages: FrameLayout
 private lateinit var status: TextView
 private val tabs = mutableListOf<WebView>()
 private var current = 0
 private val media = linkedSetOf<String>()
 private val detected = java.util.Collections.synchronizedSet(mutableSetOf<String>())
 private val shield by lazy { Shield(this) }
 private val prefs by lazy { getSharedPreferences("browser", MODE_PRIVATE) }
 private val bookmarks get() = readList("bookmarks")
 private val history get() = readList("history")
 private fun readList(key: String): MutableList<String> {
  val arr = JSONArray(prefs.getString(key,"[]")); return (0 until arr.length()).map { arr.optString(it) }.toMutableList()
 }
 private fun writeList(key: String, items: List<String>) { prefs.edit().putString(key, JSONArray(items.takeLast(300)).toString()).apply() }
 private fun button(s: String, action: () -> Unit): Button = Button(this).apply { text=s; setOnClickListener { action() }; textSize=12f; setAllCaps(false) }
 private fun navButton(icon: String, description: String, action: () -> Unit): TextView = TextView(this).apply {
  text = icon; textSize = 23f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
  contentDescription = description; setBackgroundResource(android.R.drawable.list_selector_background)
  setOnClickListener { action() }
 }
 private fun row(): LinearLayout = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
  window.statusBarColor=Color.rgb(19,24,32); window.navigationBarColor=Color.rgb(19,24,32)
  root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(19,24,32)) }; setContentView(root)
  val top=row(); root.addView(top)
  address=EditText(this).apply { setSingleLine(true); hint="Адрес или поиск"; inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY) }
  top.addView(address,LinearLayout.LayoutParams(0,dp(52),1f)); top.addView(button("Перейти") { navigate(address.text.toString()) })
  address.setOnEditorActionListener { _,_,_ -> navigate(address.text.toString()); true }
  pages=FrameLayout(this); root.addView(pages,LinearLayout.LayoutParams(-1,0,1f))
  status=TextView(this).apply { setTextColor(Color.LTGRAY); textSize=11f; text="Готов" }; root.addView(status)
  val bottom=row(); root.addView(bottom)
  listOf("‹","›","+","▣","★","♫","⋮").forEachIndexed { i,s ->
   val action: () -> Unit = when(i) { 0->{ { active().takeIf{it.canGoBack()}?.goBack() } }; 1->{ { active().takeIf{it.canGoForward()}?.goForward() } }; 2->{ { addTab("https://www.google.com") } }; 3->{ { showTabs() } }; 4->{ { showBookmarks() } }; 5->{ { showMedia() } }; else->{ { showMenu() } } }
   val descriptions = listOf("Назад", "Вперёд", "Новая вкладка", "Вкладки", "Закладки", "Медиа", "Меню")
   bottom.addView(navButton(s, descriptions[i], action),LinearLayout.LayoutParams(0,dp(50),1f))
  }
  // A failed WebView initialization should not terminate the entire app.
  try {
   addTab("https://www.google.com")
  } catch (error: Throwable) {
   getSharedPreferences("diagnostics", MODE_PRIVATE).edit()
    .putString("last_crash", android.util.Log.getStackTraceString(error).take(18000)).apply()
   status.text = "Не удалось запустить WebView"
   AlertDialog.Builder(this).setTitle("Ошибка запуска WebView")
    .setMessage("Открой диагностику и скопируй отчёт.")
    .setPositiveButton("Диагностика") { _, _ -> startActivity(Intent(this, DiagnosticActivity::class.java)) }
    .setNegativeButton("Закрыть", null).show()
  }
  try { shield.updateIfDue() } catch (_: Exception) { }

 }
 private fun dp(n:Int)=(n*resources.displayMetrics.density).toInt()
 private fun active()=tabs[current]
 private fun addTab(url:String) {
  val web=WebView(this); web.settings.apply { javaScriptEnabled=true; domStorageEnabled=true; mediaPlaybackRequiresUserGesture=true; builtInZoomControls=true; displayZoomControls=false; allowFileAccess=false; allowContentAccess=false; mixedContentMode=WebSettings.MIXED_CONTENT_NEVER_ALLOW }
  web.webChromeClient=object:WebChromeClient() {
   override fun onShowCustomView(view:View,callback:CustomViewCallback) { val dialog=Dialog(this@MainActivity,android.R.style.Theme_Black_NoTitleBar_Fullscreen); dialog.setContentView(view); dialog.setOnDismissListener { callback.onCustomViewHidden() }; dialog.show(); view.setOnLongClickListener { dialog.dismiss(); true } }
  }
  web.webViewClient=object:WebViewClient() {
   override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
    val u=request?.url?.toString()
    if(u!=null && Regex("\\.(mp4|mp3|m4a|aac|webm|m3u8|mpd|m4v|ogg)(\\?|$)",RegexOption.IGNORE_CASE).containsMatchIn(u)) detected.add(u)
    if (request != null && shield.shouldBlock(request.url, request.isForMainFrame)) return WebResourceResponse("text/plain", "UTF-8", java.io.ByteArrayInputStream(ByteArray(0)))
    return super.shouldInterceptRequest(view,request)
   }
   override fun shouldOverrideUrlLoading(v:WebView?,r:WebResourceRequest?):Boolean { val u=r?.url ?:return false; return if(u.scheme=="http"||u.scheme=="https") false else { try { startActivity(Intent(Intent.ACTION_VIEW,u)) } catch (_:Exception){}; true } }
   override fun onPageFinished(v:WebView?,url:String?) { if(v==active()) { address.setText(url); status.text="Готов · найдено медиа: ${media.size}" }; if(url?.startsWith("https://")==true) { val h=history; h.remove(url); h.add(url); writeList("history",h) }; scanPage(v) }
  }
  web.setDownloadListener { url,ua,disposition,mime,_ -> if(url.startsWith("https://")||url.startsWith("http://")) confirmDownload(url,ua,mime,disposition) }
  web.setOnLongClickListener { val hit=web.hitTestResult; val u=hit.extra; if(u!=null && u.startsWith("http")) { media.add(u); status.text="Ссылка добавлена в Медиа"; true } else false }
  tabs.add(web); pages.addView(web); switchTab(tabs.lastIndex); web.loadUrl(url)
 }
 private fun switchTab(index:Int) { current=index; tabs.forEachIndexed { i,v -> v.visibility=if(i==index) View.VISIBLE else View.GONE }; address.setText(active().url ?: ""); media.clear(); detected.clear() }
 private fun navigate(raw:String) { val t=raw.trim(); if(t.isEmpty())return; val u=if(t.startsWith("https://")||t.startsWith("http://")) t else if(t.contains('.')&&!t.contains(' ')) "https://$t" else "https://www.google.com/search?q=${URLEncoder.encode(t,"UTF-8")}"; active().loadUrl(u) }
 private fun scanPage(web:WebView?) { if(web==null)return; web.evaluateJavascript("(function(){return JSON.stringify(Array.from(document.querySelectorAll('video,audio,source,a')).map(e=>e.currentSrc||e.src||e.href).filter(x=>x&&/^(https?:)/.test(x)&&(/\\.(mp4|mp3|m4a|aac|webm|m3u8|mpd)(\\?|#|$)/i.test(x)||e===document.querySelector('video'))).slice(0,150))})()") { raw ->
  try { val decoded=JSONArray("[$raw]").getString(0); val arr=JSONArray(decoded); for(i in 0 until arr.length())media.add(arr.getString(i)); status.text="Готов · найдено медиа: ${media.size}" } catch (_:Exception) {} }
 }
 private fun mediaType(url: String): String = when {
  Regex("\\.m3u8(\\?|$)", RegexOption.IGNORE_CASE).containsMatchIn(url) -> "HLS · потоковое видео"
  Regex("\\.mpd(\\?|$)", RegexOption.IGNORE_CASE).containsMatchIn(url) -> "DASH · потоковое видео"
  Regex("\\.(mp3|aac|m4a|ogg)(\\?|$)", RegexOption.IGNORE_CASE).containsMatchIn(url) -> "Аудио"
  else -> "Видео · прямой файл"
 }
 private fun mediaLabel(url: String, index: Int): String {
  val path = Uri.parse(url).path.orEmpty()
  val quality = Regex("(?:^|/)([0-9]{3,4})p?(?:/|$)", RegexOption.IGNORE_CASE).find(path)?.groupValues?.get(1)
  val kind = mediaType(url)
  return "${index + 1}. $kind" + (quality?.let { " · ${it}p" } ?: "")
 }
 private fun prettyDuration(ms: Long): String {
  if (ms <= 0L) return "Длительность неизвестна"
  val sec = ms / 1000L
  return if (sec >= 3600) "%d:%02d:%02d".format(sec/3600,(sec/60)%60,sec%60)
  else "%d:%02d".format(sec/60,sec%60)
 }
 private data class MediaDetails(val quality: String?, val durationMs: Long?, val frame: android.graphics.Bitmap?)
 private fun inspectMedia(url: String, referer: String): MediaDetails {
  var quality: String? = Regex("(?:^|/)([0-9]{3,4})p?(?:/|$)", RegexOption.IGNORE_CASE)
   .find(Uri.parse(url).path.orEmpty())?.groupValues?.get(1)?.let { "${it}p" }
  var duration: Long? = null
  var frame: android.graphics.Bitmap? = null
  // Metadata lookup is strictly best effort and never blocks the browser UI.
  if (url.contains(".m3u8",true)) {
   try {
    val conn = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
     connectTimeout=3500; readTimeout=3500
     setRequestProperty("User-Agent", "Mozilla/5.0 (Android) V&R Browser")
     if(referer.startsWith("http"))setRequestProperty("Referer",referer)
    }
    try {
     val playlist = conn.inputStream.bufferedReader().use { it.readText().take(350000) }
     if (playlist.startsWith("#EXTM3U")) {
      val resolution = Regex("RESOLUTION=(\\d+)x(\\d+)").find(playlist)
      if (resolution != null) quality = "${resolution.groupValues[2]}p"
      if (playlist.contains("#EXTINF:")) {
       val seconds = Regex("#EXTINF:([0-9]+(?:\\.[0-9]+)?)").findAll(playlist)
        .sumOf { it.groupValues[1].toDoubleOrNull() ?: 0.0 }
       if (seconds > 0.0) duration=(seconds*1000).toLong()
      }
     }
    } finally { conn.disconnect() }
   } catch (_: Exception) { }
  }
  try {
   val retriever = android.media.MediaMetadataRetriever()
   try {
    retriever.setDataSource(url, mapOf("User-Agent" to "Mozilla/5.0 (Android)", "Referer" to referer))
    val height = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()
    if (height != null && height > 0) quality="${height}p"
    val length = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
    if (length != null && length > 0) duration=length
    frame = retriever.getFrameAtTime(1000000L, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
   } finally { retriever.release() }
  } catch (_: Exception) { }
  return MediaDetails(quality,duration,frame)
 }
 private fun showMedia() {
  scanPage(active())
  Handler(Looper.getMainLooper()).postDelayed({
   media.addAll(detected)
   val entries = media.toList().distinct().filter { it.startsWith("https://") || it.startsWith("http://") }
   if(entries.isEmpty()) { alert("Медиа", "Запусти видео на странице и попробуй снова."); return@postDelayed }
   val pageTitle = active().title?.take(48) ?: "Видео со страницы"
   val referer = active().url.orEmpty()
   val list = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(6),dp(3),dp(6),dp(3)) }
   entries.forEachIndexed { index, url ->
    val item = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(dp(4),dp(6),dp(4),dp(6)) }
    val thumb = ImageView(this).apply {
     setImageResource(android.R.drawable.ic_media_play)
     setBackgroundColor(Color.rgb(50,55,65)); setPadding(dp(8),dp(8),dp(8),dp(8))
     scaleType=ImageView.ScaleType.CENTER_INSIDE
     contentDescription="Предпросмотр видео"
    }
    item.addView(thumb,LinearLayout.LayoutParams(dp(76),dp(52)))
    val info=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(9),0,dp(3),0) }
    val heading=TextView(this).apply { text="${index+1}. ${pageTitle}"; textSize=13f; maxLines=1; ellipsize=android.text.TextUtils.TruncateAt.END; setTextColor(Color.WHITE) }
    val metadata=TextView(this).apply {
     text="${mediaType(url).substringBefore(" · ")} · Определяем параметры…"; textSize=11f; setTextColor(Color.LTGRAY)
     maxLines=2
    }
    info.addView(heading); info.addView(metadata)
    item.addView(info,LinearLayout.LayoutParams(0,-2,1f))
    val download=TextView(this).apply {
     text="↓"; textSize=27f; gravity=Gravity.CENTER; setTextColor(Color.WHITE)
     contentDescription="Скачать видео ${index+1}"
     setOnClickListener { confirmDownload(url,"","","") }
    }
    item.addView(download,LinearLayout.LayoutParams(dp(42),dp(48)))
    thumb.setOnClickListener { startActivity(Intent(this,PlayerActivity::class.java).putExtra("url",url)) }
    info.setOnClickListener { showMediaActions(url,mediaLabel(url,index)) }
    list.addView(item)
    list.addView(View(this).apply { setBackgroundColor(Color.DKGRAY) },LinearLayout.LayoutParams(-1,dp(1)))
    Thread {
     val details=inspectMedia(url,referer)
     runOnUiThread {
      if (isFinishing || isDestroyed) return@runOnUiThread
      val resolution=details.quality ?: "Качество неизвестно"
      metadata.text="${mediaType(url).substringBefore(" · ")} · $resolution · ${details.durationMs?.let { prettyDuration(it) } ?: "Длительность неизвестна"}"
      details.frame?.let { bitmap ->
       thumb.setPadding(0,0,0,0); thumb.scaleType=ImageView.ScaleType.CENTER_CROP
       thumb.setImageBitmap(bitmap); thumb.contentDescription="Кадр видео"
      }
     }
    }.start()
   }
   val scroll=ScrollView(this).apply { addView(list) }
   AlertDialog.Builder(this).setTitle("Найдено медиа (${entries.size})")
    .setView(scroll).setNegativeButton("Закрыть",null).show()
  },450)
 }
 private fun showMediaActions(url:String, label:String) {
  val choices=arrayOf("Смотреть", "Скачать", "Поделиться ссылкой", "Копировать ссылку", "Технический адрес")
  AlertDialog.Builder(this).setTitle(label).setItems(choices) { _,choice -> when(choice) {
   0 -> startActivity(Intent(this, PlayerActivity::class.java).putExtra("url",url))
   1 -> confirmDownload(url,"","","")
   2 -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type="text/plain"; putExtra(Intent.EXTRA_TEXT,url) },"Поделиться"))
   3 -> (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(ClipData.newPlainText("Media URL",url))
   4 -> alert("Адрес потока",url.take(1200))
  } }.show()
 }
 private fun confirmDownload(url:String,ua:String,mime:String,disposition:String) {
  if(Regex("\\.mpd(\\?|$)",RegexOption.IGNORE_CASE).containsMatchIn(url)) { alert("DASH", "Загрузка DASH пока не поддерживается. Воспроизведение доступно во встроенном плеере."); return }
  if(Regex("\\.m3u8(\\?|$)",RegexOption.IGNORE_CASE).containsMatchIn(url)) {
   AlertDialog.Builder(this).setTitle("Скачать HLS?")
    .setMessage("Поддерживаются завершённые незашифрованные MPEG-TS плейлисты. Сохраняем исходный .ts со звуком, без ненадёжной конвертации в MP4. Скачивайте только контент, на который у вас есть права.")
    .setPositiveButton("Скачать") { _, _ ->
     val referer = active().url ?: ""
     HlsDownloader(applicationContext).download(url, referer) { message ->
      Toast.makeText(this, message, Toast.LENGTH_LONG).show()
     }
     Toast.makeText(this, "Загрузка HLS запущена", Toast.LENGTH_SHORT).show()
    }.setNegativeButton("Отмена", null).show()
   return
  }
  AlertDialog.Builder(this).setTitle("Скачать файл?").setMessage(url.take(250)).setPositiveButton("Скачать") { _,_ -> try {
   val req=DownloadManager.Request(Uri.parse(url)).setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
   if(ua.isNotBlank())req.addRequestHeader("User-Agent",ua)
   val referer=active().url; if(referer?.startsWith("http")==true)req.addRequestHeader("Referer",referer)
   val name=URLUtil.guessFileName(url,disposition,mime).replace(Regex("[^a-zA-Z0-9._ -]"),"_")
   req.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS,name)
   (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req); Toast.makeText(this,"Загрузка начата",Toast.LENGTH_SHORT).show()
  } catch(e:Exception) { alert("Ошибка",e.message?:"Не удалось скачать") } }.setNegativeButton("Отмена",null).show()
 }
 private fun showTabs() { AlertDialog.Builder(this).setTitle("Вкладки").setItems(tabs.mapIndexed { i,v -> "${i+1}. ${(v.title?:v.url?:"Новая вкладка").take(55)}" }.toTypedArray()) { _,i -> switchTab(i) }.setPositiveButton("Новая") { _,_->addTab("https://www.google.com") }.setNeutralButton("Закрыть текущую") { _,_-> if(tabs.size>1) { val old=active(); tabs.removeAt(current); pages.removeView(old); old.destroy(); switchTab(tabs.lastIndex) } }.show() }
 private fun showBookmarks() { val list=bookmarks; AlertDialog.Builder(this).setTitle("Закладки").setItems(list.toTypedArray()) { _,i -> navigate(list[i]) }.setPositiveButton("Добавить текущую") { _,_-> val u=active().url; if(u!=null){ list.remove(u); list.add(u); writeList("bookmarks",list) } }.setNegativeButton("Закрыть",null).show() }
 private fun showMenu() { val choices=arrayOf("История","Библиотека загрузок","Обновить","Очистить историю","Очистить данные сайтов","V&R Shield","Диагностика")
  AlertDialog.Builder(this).setItems(choices) { _,i -> when(i) { 0->{ val h=history.reversed(); AlertDialog.Builder(this).setTitle("История").setItems(h.toTypedArray()) { _,j -> navigate(h[j]) }.show() }; 1->startActivity(Intent(this, LibraryActivity::class.java)); 2->active().reload(); 3->writeList("history",emptyList()); 5->showShield(); 6->startActivity(Intent(this, DiagnosticActivity::class.java)); 4->AlertDialog.Builder(this).setMessage("Удалить cookies и кэш браузера?").setPositiveButton("Удалить") { _,_->CookieManager.getInstance().removeAllCookies(null); tabs.forEach{it.clearCache(true)} }.setNegativeButton("Отмена",null).show() } }.show()
 }
 private fun showShield() {
  val modes=arrayOf("Выключен", "Сбалансированный", "Строгий")
  val current=shield.mode()
  AlertDialog.Builder(this).setTitle("V&R Shield · режим").setSingleChoiceItems(modes,current) { dialog,which -> shield.setMode(which); dialog.dismiss(); Toast.makeText(this,"Режим сохранён",Toast.LENGTH_SHORT).show() }
   .setPositiveButton("Обновить фильтры") { _,_ -> shield.updateNow { result -> runOnUiThread { alert("Фильтры",result) } } }
   .setNeutralButton("Исключения") { _,_ -> val input=EditText(this).apply { setText(shield.exclusions()); hint="example.com, другой-сайт.ru" }; AlertDialog.Builder(this).setTitle("Сайты без блокировки").setView(input).setPositiveButton("Сохранить") { _,_ -> shield.setExclusions(input.text.toString()) }.setNegativeButton("Отмена",null).show() }
   .setNegativeButton("Закрыть",null).show()
 }
 private fun alert(title:String,msg:String) { AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("OK",null).show() }
 override fun onBackPressed() { if(active().canGoBack())active().goBack() else super.onBackPressed() }
 override fun onDestroy() { tabs.forEach { it.destroy() }; super.onDestroy() }
}
