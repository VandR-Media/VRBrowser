package com.vrbrowser.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Lightweight persistent transfer state for HLS downloads. */
object TransferStore {
 data class Entry(val id: String, val name: String, val state: String, val progress: Int, val bytes: Long, val uri: String, val speed: Long, val etaSeconds: Long)
 private val lock = Any()
 private fun prefs(context: Context) = context.getSharedPreferences("hls_transfers", Context.MODE_PRIVATE)
 fun update(context: Context, id: String, name: String, state: String, progress: Int, bytes: Long, uri: String = "", speed: Long = 0, etaSeconds: Long = -1) = synchronized(lock) {
  val p = prefs(context)
  val arr = try { JSONArray(p.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
  val next = JSONArray()
  next.put(JSONObject().put("id", id).put("name", name).put("state", state).put("progress", progress.coerceIn(0, 100)).put("bytes", bytes).put("uri", uri).put("speed", speed).put("eta", etaSeconds))
  for (i in 0 until minOf(arr.length(), 99)) {
   val old = arr.optJSONObject(i) ?: continue
   if (old.optString("id") != id) next.put(old)
  }
  p.edit().putString("items", next.toString()).apply()
 }
 fun remove(context: Context, id: String) = synchronized(lock) {
  val p = prefs(context)
  val arr = try { JSONArray(p.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
  val next = JSONArray()
  for (i in 0 until arr.length()) { val item = arr.optJSONObject(i) ?: continue; if (item.optString("id") != id) next.put(item) }
  p.edit().putString("items", next.toString()).apply()
 }
 fun entries(context: Context): List<Entry> = synchronized(lock) {
  val arr = try { JSONArray(prefs(context).getString("items", "[]")) } catch (_: Exception) { JSONArray() }
  (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.let {
   Entry(it.optString("id"), it.optString("name"), it.optString("state"), it.optInt("progress"), it.optLong("bytes"), it.optString("uri"), it.optLong("speed"), it.optLong("eta", -1))
  } }
 }
}
