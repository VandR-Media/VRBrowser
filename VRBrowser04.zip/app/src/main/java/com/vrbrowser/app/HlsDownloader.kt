package com.vrbrowser.app

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.os.Handler
import android.os.Looper
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/** Downloads finite, unencrypted MPEG-TS HLS playlists. Does not remux or bypass DRM. */
class HlsDownloader(private val context: Context) {
 private val executor = Executors.newSingleThreadExecutor()
 private val main = Handler(Looper.getMainLooper())
 private fun notify(callback: (String) -> Unit, message: String) = main.post { callback(message) }
 private fun connect(url: URL, referer: String): HttpURLConnection {
  require(url.protocol == "https" || url.protocol == "http") { "Неподдерживаемый протокол" }
  return (url.openConnection() as HttpURLConnection).apply {
   connectTimeout = 15000; readTimeout = 30000; instanceFollowRedirects = true
   setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
   if (referer.startsWith("http")) setRequestProperty("Referer", referer)
  }
 }
 private fun playlist(url: URL, referer: String): String {
  val c = connect(url, referer)
  try {
   check(c.responseCode == 200) { "HTTP ${c.responseCode}" }
   return c.inputStream.bufferedReader().use { it.readText().take(2_000_001) }.also {
    check(it.length <= 2_000_000 && it.startsWith("#EXTM3U")) { "Некорректный плейлист" }
   }
  } finally { c.disconnect() }
 }
 fun download(source: String, referer: String, callback: (String) -> Unit) {
  executor.execute {
   var uri: android.net.Uri? = null
   try {
    var url = URL(source)
    var content = playlist(url, referer)
    repeat(3) {
     if (content.contains("#EXT-X-STREAM-INF")) {
      val lines = content.lines()
      val variants = lines.indices.filter { lines[it].startsWith("#EXT-X-STREAM-INF") && it + 1 < lines.size }
      val next = variants.lastOrNull()?.let { lines[it + 1].trim() } ?: error("Нет варианта потока")
      url = URL(url, next); content = playlist(url, referer)
     }
    }
    check(!content.contains("#EXT-X-STREAM-INF")) { "Слишком много вложенных плейлистов" }
    check(content.contains("#EXT-X-ENDLIST")) { "Прямой эфир не поддерживается" }
    check(!content.contains("#EXT-X-KEY") && !content.contains("#EXT-X-SESSION-KEY")) { "Шифрованные потоки не поддерживаются" }
    check(!content.contains("#EXT-X-MAP") && !content.contains("#EXT-X-BYTERANGE")) { "Этот формат HLS пока не поддерживается" }
    val segments = content.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }
    check(segments.isNotEmpty() && segments.size <= 10000) { "Некорректное число сегментов" }
    check(segments.all { URL(url, it).path.lowercase().endsWith(".ts") }) { "Поддерживаются только MPEG-TS сегменты" }
    val name = "VRBrowser_${System.currentTimeMillis()}.ts"
    val values = ContentValues().apply {
     put(MediaStore.Downloads.DISPLAY_NAME, name)
     put(MediaStore.Downloads.MIME_TYPE, "video/mp2t")
     put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/VRBrowser")
     put(MediaStore.Downloads.IS_PENDING, 1)
    }
    check(Build.VERSION.SDK_INT >= 29) { "Для сохранения требуется Android 10 или новее" }
    uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
     ?: error("Не удалось создать файл")
    context.contentResolver.openOutputStream(uri!!)?.use { output ->
     segments.forEachIndexed { index, segment ->
      val c = connect(URL(url, segment), referer)
      try {
       check(c.responseCode == 200) { "Сегмент ${index + 1}: HTTP ${c.responseCode}" }
       c.inputStream.use { input -> input.copyTo(output, 32768) }
      } finally { c.disconnect() }
      if ((index + 1) % 25 == 0) notify(callback, "Загружено ${index + 1}/${segments.size} сегментов")
     }
    } ?: error("Не удалось открыть файл")
    context.contentResolver.update(uri!!, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
    notify(callback, "Сохранено в Загрузки/VRBrowser: $name")
   } catch (e: Exception) {
    if (uri != null) context.contentResolver.delete(uri!!, null, null)
    notify(callback, "Ошибка HLS: ${e.message ?: e.javaClass.simpleName}")
   }
  }
 }
}
