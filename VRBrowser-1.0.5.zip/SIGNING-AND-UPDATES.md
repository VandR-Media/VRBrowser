# V&R Browser — подпись и обновления

Для обновления поверх установленного приложения сохраняйте один и тот же release keystore и applicationId=com.vrbrowser.app.

GitHub Actions использует секреты:
- VR_KEYSTORE_BASE64 (или прежнее имя VR_KEYSTORE_B64)
- VR_KEYSTORE_PASSWORD
- VR_KEY_ALIAS
- VR_KEY_PASSWORD

Не добавляйте .jks, пароли или base64 ключа в репозиторий. Храните резервную копию keystore вне GitHub.

Текущая версия: versionCode=1005, versionName=1.0.5. Для следующего выпуска увеличивайте versionCode и сохраняйте исходный сертификат подписи.

Workflow собирает только VRBrowser-1.0.5.zip, проверяет метаданные и подпись APK и публикует artifact VRBrowser-1.0.5-SIGNED-RELEASE.

Если установленное приложение подписано другим сертификатом, Android не примет обновление поверх него. В таком случае потребуется однократная переустановка; заранее сохраните нужные данные.
