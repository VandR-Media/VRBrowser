V&R Browser 1.0.2
- Neon logo wallpaper for dialogs and downloads library.
- Expand HLS master playlists into individually selectable variant URLs, each bound to its own download button.
- Avoid incorrect HLS metadata retriever quality/duration overrides.
- Improve media labels and size handling.
- GitHub Actions builds exclusively from VRBrowser-1.0.2.zip.
