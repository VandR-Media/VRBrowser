# V&R Browser 0.6

- Remux unencrypted MPEG-TS HLS to MP4 using Android MediaExtractor/MediaMuxer when tracks/codecs are compatible. Falls back to original .ts otherwise.
- Download library: open, share, delete completed HLS files.
- Stable release signing via GitHub Actions secrets and private keystore.

Limitations: Remux is not transcoding; unsupported codecs/streams stay .ts. Background HLS downloads are not yet guaranteed when Android terminates the process. No DRM bypass. Existing 0.5 debug APK cannot be upgraded in-place to the new release signing key; uninstall once after saving data. Future 0.6+ releases can upgrade in-place if the same keystore is used.
