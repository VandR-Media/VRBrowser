# V&R Browser 0.4.0 — experimental HLS download

- Keeps the approved neon launcher icon and existing browser/player/diagnostics.
- Adds download of finite, unencrypted HLS playlists containing MPEG-TS `.ts` segments.
- Writes `.ts` output into Downloads/VRBrowser via MediaStore on Android 10+.
- Rejects live, encrypted, byte-range, fMP4, DASH and unsupported playlists; does not convert to MP4 or MP3.
- Download runs while the application process remains alive; no pause/resume or persistent background service yet.
- Shield.kt already contains a compatibility-safe stream-reading implementation without `readNBytes`.

## GitHub upload
Unpack ZIP first. Upload project files and folders preserving paths, or use GitHub web editor to replace individual files. GitHub does not automatically unpack a ZIP uploaded into a repository. Existing `.github/workflows/android.yml` builds an APK and uploads it as an Actions artifact.

## Verification
Source-level changes only. APK compilation and device playback/download have not been verified here. Test on your Huawei with a permitted, unencrypted VOD HLS MPEG-TS source.
