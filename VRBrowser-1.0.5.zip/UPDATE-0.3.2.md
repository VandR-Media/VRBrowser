V&R Browser 0.3.2

Fixed AndroidManifest.xml XML escaping and replaced InputStream.readNBytes with Android-compatible bounded reading in Shield.kt.
VersionCode 5, versionName 0.3.2. No guarantee of fixing unrelated startup crashes.
