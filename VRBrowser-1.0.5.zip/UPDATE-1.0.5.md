# Update 1.0.5 — download reliability

- Correct pause/resume control for HLS and direct transfers.
- Reconnect and retry after temporary network loss.
- Preserve complete HLS segments and validate HTTP Range resume for direct files.
- Reuse WebView cookies and user-agent for media requests.
- Persist SAF destination permission for recovery after process restart.
- Do not mark a task complete until the output file is committed.
- Treat HTTP 401/403 as an expired source URL and direct the user back to the source page.
- Fix MIME type selection and remove the duplicate diagnostics launcher icon.

Known limits: live HLS, DRM, AES-128, fMP4 HLS, byte-range HLS and DASH download are not implemented.
