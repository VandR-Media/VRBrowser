V&R Browser 1.0.1
- Approximate size in detected media list (HLS segment samples, direct-file Content-Length).
- ZIP-only GitHub Actions workflow.
- versionCode 1001.
