# V&R Browser 0.5.0

- Compact icon-based navigation bar with accessibility labels (no wrapped words).
- HLS download progress saved per completed segment; bytes and completion state shown in Downloads.
- Download library refreshes every 1.5 seconds while visible and also lists Android DownloadManager files.
- Existing unencrypted finite MPEG-TS HLS downloader, player, ad shield and original launcher icons retained.
- Does not convert TS to MP4/MP3. Does not download encrypted HLS or DASH.
- Progress is segment-based, not byte-accurate. Downloads are not yet foreground services; Android may interrupt them in background.
