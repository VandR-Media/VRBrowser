# V&R Browser 0.8

- Rounded dark address bar, compact navigation button, neon-blue and pink controls.
- Rounded media thumbnails, compact media rows and shorter HLS confirmation.
- Existing HLS downloader left unchanged.
- Version code increased to 12.
- GitHub Actions builds a persistent-key signed release APK when all signing secrets are configured; otherwise it builds a debug APK.

## Permanent signing
Set GitHub repository Actions secrets:
- VR_KEYSTORE_BASE64: base64 of your existing JKS keystore (do not commit the key)
- VR_KEYSTORE_PASSWORD: JKS password
- VR_KEY_ALIAS: alias of the signing key (usually vrbrowser)
- VR_KEY_PASSWORD: key password

Use the SAME original signing key as the installed release APK for in-place updates. A debug-signed APK and a release-signed APK cannot update each other in place. Do not delete an installed app without backing up browser data first.

If secrets are not configured, the workflow produces a debug-signed APK only; it does not provide a stable signing identity across different CI machines.
