package com.vrbrowser.app

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.ConcurrentHashMap

/** Resumable finite, unencrypted MPEG-TS downloader. Segments are committed atomically. */
object HlsDownloader {
 private val pool = Executors.newFixedThreadPool(2)
 private val running = ConcurrentHashMap.newKeySet<String>()
 private val main = Handler(Looper.getMainLooper())
 private val connections = ConcurrentHashMap<String, HttpURLConnection>()
 private fun stopped(context: Context, id: String): Boolean =
  TransferStore.entries(context).firstOrNull { it.id == id }?.state in listOf("Пауза", "Удалено")
 private fun connect(url: URL, referer: String): HttpURLConnection = (url.openConnection() as HttpURLConnection).apply {
  connectTimeout=12000; readTimeout=20000; instanceFollowRedirects=true
  setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
  if(referer.startsWith("http"))setRequestProperty("Referer",referer)
 }
 private fun text(url: URL, referer: String): String {
  val c=connect(url,referer)
  try { check(c.responseCode==200) { "HTTP ${c.responseCode}" }; return c.inputStream.bufferedReader().use { it.readText().take(2000001) }.also { check(it.length<=2000000 && it.trimStart().startsWith("#EXTM3U")) { "Некорректный HLS" } } }
  finally { c.disconnect() }
 }
 fun start(context: Context, id: String, callback: (String)->Unit = {}) {
  if(!running.add(id)) {
   // A paused worker is still unwinding; queue a new attempt after it exits.
   pool.execute {
    repeat(80) { if(!running.contains(id)) { if(TransferStore.entries(context).firstOrNull { it.id==id }?.state=="Подготовка")start(context,id,callback);return@execute }; Thread.sleep(100) }
   }
   return
  }
  val app=context.applicationContext
  pool.execute {
   try { perform(app,id,callback) }
   finally { running.remove(id) }
  }
 }
 fun pause(context:Context,id:String) {
  TransferStore.setState(context,id,"Пауза")
  connections[id]?.disconnect()
 }
 fun delete(context:Context,id:String) {
  TransferStore.setState(context,id,"Удалено")
  connections[id]?.disconnect()
  if(!running.contains(id)) cleanup(context,id)
 }
 private fun cleanup(context:Context,id:String) {
  val item=TransferStore.entries(context).firstOrNull{it.id==id} ?: return
  if(item.uri.isNotBlank()) try { context.contentResolver.delete(Uri.parse(item.uri),null,null) }catch(_:Exception){}
  File(context.filesDir,"hls_$id").deleteRecursively()
  File(context.filesDir,"direct_$id.part").delete()
  TransferStore.remove(context,id)
 }
 private fun perform(context:Context,id:String,callback:(String)->Unit) {
  val initial=TransferStore.entries(context).firstOrNull{it.id==id} ?: return
  val folder=File(context.filesDir,"hls_$id").apply{mkdirs()}
  var bytes=initial.bytes
  var progress=initial.progress
  fun state(value:String,pct:Int,rate:Long=0,eta:Long=-1) {
   progress=pct
   TransferStore.update(context,id,initial.name,value,pct,bytes,initial.uri,rate,eta,initial.source,initial.referer)
  }
  try {
   check(initial.source.isNotBlank() && initial.uri.isNotBlank()) { "Отсутствует адрес или место сохранения" }
   var url=URL(initial.source)
   var body=text(url,initial.referer)
   repeat(3) {
    if(body.contains("#EXT-X-STREAM-INF")) {
     val lines=body.lines()
     val next=lines.indices.firstOrNull{lines[it].trim().startsWith("#EXT-X-STREAM-INF")}
      ?.let { i -> lines.drop(i+1).firstOrNull{it.trim().isNotEmpty()&&!it.trim().startsWith("#")} }
      ?: error("Не найден вариант HLS")
     url=URL(url,next.trim());body=text(url,initial.referer)
    }
   }
   check(!body.contains("#EXT-X-STREAM-INF")) { "Слишком глубокий плейлист" }
   check(body.contains("#EXT-X-ENDLIST")) { "Прямой эфир не поддерживается" }
   check(!body.contains("#EXT-X-KEY") && !body.contains("#EXT-X-MAP") && !body.contains("#EXT-X-BYTERANGE")) { "Шифрование/fMP4/byte-range не поддерживаются" }
   val segments=body.lines().map{it.trim()}.filter{it.isNotEmpty()&&!it.startsWith("#")}
   check(segments.isNotEmpty()&&segments.size<=10000) { "Некорректный плейлист" }
   check(segments.all{URL(url,it).path.lowercase().endsWith(".ts")}) { "Требуются MPEG-TS сегменты" }
   // Manifest fingerprint prevents combining segments from a changed playlist.
   val fingerprint=java.security.MessageDigest.getInstance("SHA-256").digest((url.toString()+"\n"+segments.joinToString("\n")).toByteArray()).joinToString(""){ "%02x".format(it) }
   val marker=File(folder,"manifest.sha256")
   if(marker.exists()&&marker.readText()!=fingerprint) {
    folder.listFiles()?.filter{it.name.endsWith(".ts")||it.name.endsWith(".part")}?.forEach{it.delete()}
   }
   marker.writeText(fingerprint)
   // Include committed segments from previous attempts in progress and byte count.
   bytes=segments.indices.sumOf { i -> File(folder,"%06d.ts".format(i)).takeIf { it.isFile }?.length() ?: 0L }
   val began=android.os.SystemClock.elapsedRealtime()
   var downloadedThisRun=0L
   var completedThisRun=0
   for((index,segment) in segments.withIndex()) {
    val current=TransferStore.entries(context).firstOrNull{it.id==id} ?: return
    if(current.state=="Удалено") { cleanup(context,id);return }
    if(current.state=="Пауза") { state("Пауза",progress);return }
    val target=File(folder,"%06d.ts".format(index))
    val existed=target.isFile && target.length()>0L
    if(!target.exists()||target.length()==0L) {
     var last:Exception?=null
     for(attempt in 1..4) {
      val part=File(folder,"%06d.part".format(index))
      try {
       part.delete()
       if(stopped(context,id)) { state("Пауза",progress);return }
       val c=connect(URL(url,segment),initial.referer)
       connections[id]=c
       try { check(c.responseCode==200) { "HTTP ${c.responseCode}" }; c.inputStream.use { input -> part.outputStream().use { output ->
        val buffer=ByteArray(32768)
        while(true) {
         if(stopped(context,id)) throw java.io.InterruptedIOException("Приостановлено")
         val n=input.read(buffer)
         if(n<0)break
         output.write(buffer,0,n)
        }
       }} }
       finally { connections.remove(id,c); c.disconnect() }
       check(part.length()>0) { "Пустой сегмент" }
       check(part.renameTo(target)) { "Ошибка сохранения сегмента" }
       last=null;break
      } catch(e:Exception) {
        last=e;part.delete()
        if(stopped(context,id)) { state("Пауза",progress);return }
        if(e.message?.contains("HTTP 403")==true || e.message?.contains("HTTP 401")==true)break
        if(attempt<4)Thread.sleep(700L*attempt)
       }
     }
     if(last!=null)throw IOException("Сегмент ${index+1}: ${last.message}")
    }
    if(!target.exists())error("Не сохранён сегмент ${index+1}")
    if(!existed) { downloadedThisRun+=target.length();completedThisRun++ }
    bytes=segments.indices.sumOf { i -> File(folder,"%06d.ts".format(i)).takeIf { it.isFile }?.length() ?: 0L }
    val elapsed=(android.os.SystemClock.elapsedRealtime()-began).coerceAtLeast(1000L)
    val rate=downloadedThisRun*1000/elapsed
    val remaining=if(completedThisRun>0) (elapsed/1000.0*(segments.size-index-1)/completedThisRun).toLong().coerceAtLeast(0) else -1
    state("Загрузка",(index+1)*100/segments.size,rate,remaining)
   }
   if(stopped(context,id)) { state("Пауза",progress);return }
   // Output is created only after all segments are present; retries never duplicate bytes.
   context.contentResolver.openOutputStream(Uri.parse(initial.uri),"wt")?.use { out ->
    for(index in segments.indices) File(folder,"%06d.ts".format(index)).inputStream().use{it.copyTo(out,32768)}
   } ?: error("Не удалось открыть выбранный файл")
   state("Готово",100)
   folder.deleteRecursively()
   main.post { callback("Загрузка завершена: ${initial.name}") }
  } catch(e:Exception) {
   if(stopped(context,id)) {
    if(TransferStore.entries(context).any { it.id==id && it.state=="Удалено" }) cleanup(context,id)
    else state("Пауза",progress)
    return
   }
   state("Ошибка: ${e.message ?: "сеть"}",progress)
   main.post { callback("Загрузка приостановлена: можно повторить") }
  }
 }
}
