package com.vrbrowser.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object TransferStore {
 data class Entry(val id:String,val name:String,val state:String,val progress:Int,val bytes:Long,val uri:String,val speed:Long,val etaSeconds:Long,val source:String,val referer:String)
 private val lock=Any()
 private fun prefs(c:Context)=c.getSharedPreferences("hls_transfers",Context.MODE_PRIVATE)
 fun update(c:Context,id:String,name:String,state:String,progress:Int,bytes:Long,uri:String="",speed:Long=0,etaSeconds:Long=-1,source:String="",referer:String="")=synchronized(lock) {
  val arr=try{JSONArray(prefs(c).getString("items","[]"))}catch(_:Exception){JSONArray()}
  val next=JSONArray().put(JSONObject().put("id",id).put("name",name).put("state",state).put("progress",progress.coerceIn(0,100)).put("bytes",bytes).put("uri",uri).put("speed",speed).put("eta",etaSeconds).put("source",source).put("referer",referer))
  for(i in 0 until minOf(arr.length(),99))arr.optJSONObject(i)?.let{if(it.optString("id")!=id)next.put(it)}
  prefs(c).edit().putString("items",next.toString()).commit()
 }
 fun setState(c:Context,id:String,state:String) { entries(c).firstOrNull{it.id==id}?.let{update(c,id,it.name,state,it.progress,it.bytes,it.uri,it.speed,it.etaSeconds,it.source,it.referer)} }
 fun remove(c:Context,id:String)=synchronized(lock) {
  val arr=try{JSONArray(prefs(c).getString("items","[]"))}catch(_:Exception){JSONArray()};val next=JSONArray()
  for(i in 0 until arr.length())arr.optJSONObject(i)?.let{if(it.optString("id")!=id)next.put(it)}
  prefs(c).edit().putString("items",next.toString()).commit()
 }
 fun entries(c:Context):List<Entry> =synchronized(lock) {
  val arr=try{JSONArray(prefs(c).getString("items","[]"))}catch(_:Exception){JSONArray()}
  (0 until arr.length()).mapNotNull{arr.optJSONObject(it)?.let{j->Entry(j.optString("id"),j.optString("name"),j.optString("state"),j.optInt("progress"),j.optLong("bytes"),j.optString("uri"),j.optLong("speed"),j.optLong("eta",-1),j.optString("source"),j.optString("referer"))}}
 }
}
