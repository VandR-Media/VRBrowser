package com.vrbrowser.app

import android.content.Context
import android.net.Uri
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.ConcurrentHashMap

/** Direct file downloads with best-effort HTTP range resume. */
object DirectDownloader {
 private val pool=Executors.newFixedThreadPool(2)
 private val active=ConcurrentHashMap.newKeySet<String>()
 fun start(context:Context,id:String) {
  if(!active.add(id))return
  pool.execute { try { run(context.applicationContext,id) } finally { active.remove(id) } }
 }
 private fun run(c:Context,id:String) {
  val entry=TransferStore.entries(c).firstOrNull{it.id==id}?:return
  val part=File(c.filesDir,"direct_$id.part")
  try {
   val conn=(URL(entry.source).openConnection() as HttpURLConnection).apply {
    connectTimeout=12000;readTimeout=20000
    setRequestProperty("User-Agent","Mozilla/5.0 (Android) Chrome/120")
    if(entry.referer.startsWith("http"))setRequestProperty("Referer",entry.referer)
    if(part.length()>0)setRequestProperty("Range","bytes=${part.length()}-")
   }
   try {
    val code=conn.responseCode
    check(code==200||code==206){"HTTP $code"}
    if(code==200 && part.length()>0)part.delete() // Server ignored Range: restart safely.
    val total=if(code==206)conn.getHeaderField("Content-Range")?.substringAfterLast('/')?.toLongOrNull() else conn.contentLengthLong.takeIf{it>0}
    val started=android.os.SystemClock.elapsedRealtime()
    conn.inputStream.use{input->java.io.FileOutputStream(part,true).use{out->
     val buffer=ByteArray(32768)
     while(true) {
      val state=TransferStore.entries(c).firstOrNull{it.id==id}?.state ?: return
      if(state=="Пауза")return
      if(state=="Удалено") { part.delete(); return }
      val count=input.read(buffer);if(count<0)break
      out.write(buffer,0,count)
      val bytes=part.length()
      val pct=if(total!=null&&total>0)(bytes*100/total).toInt() else 0
      val elapsed=(android.os.SystemClock.elapsedRealtime()-started).coerceAtLeast(1000)
      val rate=bytes*1000/elapsed
      TransferStore.update(c,id,entry.name,"Загрузка",pct,bytes,entry.uri,rate,if(total!=null&&rate>0)(total-bytes)/rate else -1,entry.source,entry.referer)
     }
    }}
    c.contentResolver.openOutputStream(Uri.parse(entry.uri),"wt")!!.use{out->part.inputStream().use{it.copyTo(out)}}
    TransferStore.update(c,id,entry.name,"Готово",100,part.length(),entry.uri,source=entry.source,referer=entry.referer)
    part.delete()
   }finally{conn.disconnect()}
  }catch(e:Exception){TransferStore.setState(c,id,"Ошибка: ${e.message}")}
 }
}
