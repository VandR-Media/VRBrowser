package com.vrbrowser.app

import android.app.Activity
import android.app.DownloadManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.*

class LibraryActivity : Activity() {
 private val handler = Handler(Looper.getMainLooper())
 private lateinit var list: ListView
 private val actions = mutableListOf<() -> Unit>()
 private val refresh = object : Runnable {
  override fun run() { updateList(); handler.postDelayed(this, 1500) }
 }
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 16, 12, 12) }
  layout.addView(TextView(this).apply { text = "V&R Browser · загрузки"; textSize = 22f; setPadding(8, 4, 8, 16) })
  layout.addView(TextView(this).apply { text = "HLS: прогресс по сегментам. Обычные файлы: системный загрузчик."; textSize = 13f; setPadding(8, 0, 8, 12) })
  list = ListView(this)
  layout.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
  layout.addView(Button(this).apply { text = "Открыть системные загрузки"; setOnClickListener {
   startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
  } })
  setContentView(layout)
  list.setOnItemClickListener { _, _, position, _ -> actions.getOrNull(position)?.invoke() }
 }
 override fun onResume() { super.onResume(); handler.post(refresh) }
 override fun onPause() { handler.removeCallbacks(refresh); super.onPause() }
 private fun updateList() {
  val rows = mutableListOf<String>()
  actions.clear()
  for (item in TransferStore.entries(this)) {
   val size = String.format(java.util.Locale.getDefault(), "%.1f МБ", item.bytes / 1048576.0)
   rows.add("${item.name}\n${item.state} · ${item.progress}% · $size")
   actions.add {
    if (item.uri.isNotBlank()) {
     val uri = Uri.parse(item.uri)
     val mime = if (item.name.endsWith(".mp4", true)) "video/mp4" else "video/mp2t"
     val options = arrayOf("Открыть", "Поделиться", "Удалить")
     android.app.AlertDialog.Builder(this).setTitle(item.name).setItems(options) { _, choice ->
      when (choice) {
       0 -> try { startActivity(Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri, mime); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }) } catch (_: Exception) { Toast.makeText(this, "Нет подходящего плеера", Toast.LENGTH_SHORT).show() }
       1 -> try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = mime; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }, "Поделиться")) } catch (_: Exception) { Toast.makeText(this, "Не удалось поделиться", Toast.LENGTH_SHORT).show() }
       2 -> android.app.AlertDialog.Builder(this).setMessage("Удалить файл ${item.name}?").setNegativeButton("Отмена", null).setPositiveButton("Удалить") { _, _ ->
        try { contentResolver.delete(uri, null, null); TransferStore.remove(this, item.id); updateList() } catch (_: Exception) { Toast.makeText(this, "Не удалось удалить", Toast.LENGTH_SHORT).show() }
       }.show()
      }
     }.show()
    }
   }
  }
  val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
  try {
   dm.query(DownloadManager.Query()).use { cursor ->
    val idCol = cursor.getColumnIndex(DownloadManager.COLUMN_ID)
    val titleCol = cursor.getColumnIndex(DownloadManager.COLUMN_TITLE)
    val statusCol = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)
    val totalCol = cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
    val doneCol = cursor.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
    while (cursor.moveToNext()) {
     val id = cursor.getLong(idCol)
     val name = cursor.getString(titleCol) ?: "Файл"
     val status = cursor.getInt(statusCol)
     val total = cursor.getLong(totalCol)
     val done = cursor.getLong(doneCol)
     val pct = if (total > 0) "${done * 100 / total}%" else "${done / 1048576} МБ"
     val state = when(status) {
      DownloadManager.STATUS_SUCCESSFUL -> "Готово"
      DownloadManager.STATUS_FAILED -> "Ошибка"
      DownloadManager.STATUS_PAUSED -> "Приостановлено"
      DownloadManager.STATUS_RUNNING -> "Загрузка $pct"
      else -> "В очереди"
     }
     rows.add("$name\n$state")
     actions.add {
      try {
       val uri = dm.getUriForDownloadedFile(id)
       if (uri != null) startActivity(Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, "*/*"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
       })
      } catch (_: Exception) { Toast.makeText(this, "Не удалось открыть файл", Toast.LENGTH_SHORT).show() }
     }
    }
   }
  } catch (_: Exception) { }
  if (rows.isEmpty()) { rows.add("Загрузок пока нет"); actions.add {} }
  list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, rows)
 }
}
