package com.vrbrowser.app

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.media.MediaExtractor
import android.media.MediaMuxer
import android.media.MediaCodec
import android.media.MediaFormat
import java.io.File
import java.nio.ByteBuffer
import android.os.Environment
import android.provider.MediaStore
import android.os.Handler
import android.os.Looper
import java.net.HttpURLConnection
import java.net.URL
import java.io.IOException
import java.util.concurrent.Executors

/** Downloads finite, unencrypted MPEG-TS HLS playlists. Does not remux or bypass DRM. */
class HlsDownloader(private val context: Context) {
 private val executor = Executors.newSingleThreadExecutor()
 private val main = Handler(Looper.getMainLooper())
 private fun notify(callback: (String) -> Unit, message: String) = main.post { callback(message) }
 private fun connect(url: URL, referer: String): HttpURLConnection {
  require(url.protocol == "https" || url.protocol == "http") { "Неподдерживаемый протокол" }
  return (url.openConnection() as HttpURLConnection).apply {
   connectTimeout = 15000; readTimeout = 30000; instanceFollowRedirects = true
   setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
   if (referer.startsWith("http")) setRequestProperty("Referer", referer)
  }
 }
 private fun playlist(url: URL, referer: String): String {
  val c = connect(url, referer)
  try {
   check(c.responseCode == 200) { "HTTP ${c.responseCode}" }
   return c.inputStream.bufferedReader().use { it.readText().take(2_000_001) }.also {
    check(it.length <= 2_000_000 && it.startsWith("#EXTM3U")) { "Некорректный плейлист" }
   }
  } finally { c.disconnect() }
 }
 /** Require audio and video in the original TS and in the remuxed MP4.
  * A nonempty MP4 is not evidence that its audio survived. */
 private fun inspectTracks(extractor: MediaExtractor): Pair<Boolean, Boolean> {
  var video = false
  var audio = false
  for (i in 0 until extractor.trackCount) {
   val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
   if (mime.startsWith("video/")) video = true
   if (mime.startsWith("audio/")) audio = true
  }
  return Pair(video, audio)
 }
 private fun verifyMp4(file: File) {
  val checkExtractor = MediaExtractor()
  try {
   checkExtractor.setDataSource(file.absolutePath)
   val (video, audio) = inspectTracks(checkExtractor)
   check(video && audio) { "MP4 lost video or audio track" }
   // Confirm both tracks contain at least one readable media sample.
   for (i in 0 until checkExtractor.trackCount) {
    val mime = checkExtractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
    if (!mime.startsWith("video/") && !mime.startsWith("audio/")) continue
    checkExtractor.selectTrack(i)
    val sample = ByteBuffer.allocateDirect(1024 * 1024)
    check(checkExtractor.readSampleData(sample, 0) > 0) { "MP4 contains empty $mime track" }
    checkExtractor.unselectTrack(i)
   }
  } finally { checkExtractor.release() }
 }
 private fun remuxToMp4(tsUri: android.net.Uri, outputName: String): android.net.Uri {
  val temp = File.createTempFile("vr_remux_", ".mp4", context.cacheDir)
  val extractor = MediaExtractor()
  var muxer: MediaMuxer? = null
  try {
   context.contentResolver.openFileDescriptor(tsUri, "r")!!.use { fd ->
    extractor.setDataSource(fd.fileDescriptor)
    val (sourceVideo, sourceAudio) = inspectTracks(extractor)
    check(sourceVideo && sourceAudio) { "TS has no detectable video and audio tracks" }
    muxer = MediaMuxer(temp.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    val map = mutableMapOf<Int, Int>()
    for (i in 0 until extractor.trackCount) {
     val format = extractor.getTrackFormat(i)
     val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
     if (mime.startsWith("video/") || mime.startsWith("audio/")) {
      map[i] = muxer!!.addTrack(format)
      extractor.selectTrack(i)
     }
    }
    check(map.isNotEmpty()) { "No supported tracks" }
    check(map.size >= 2) { "Audio or video track cannot be remuxed" }
    muxer!!.start()
    val buffer = ByteBuffer.allocateDirect(2 * 1024 * 1024)
    val info = MediaCodec.BufferInfo()
    while (true) {
     buffer.clear()
     val size = extractor.readSampleData(buffer, 0)
     if (size < 0) break
     val track = map[extractor.sampleTrackIndex]
     if (track != null) {
      info.set(0, size, extractor.sampleTime.coerceAtLeast(0), extractor.sampleFlags)
      muxer!!.writeSampleData(track, buffer, info)
     }
     extractor.advance()
    }
    muxer!!.stop()
   }
   check(temp.length() > 0) { "Empty MP4" }
   verifyMp4(temp)
   val values = ContentValues().apply {
    put(MediaStore.Downloads.DISPLAY_NAME, outputName)
    put(MediaStore.Downloads.MIME_TYPE, "video/mp4")
    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/VRBrowser")
    put(MediaStore.Downloads.IS_PENDING, 1)
   }
   val target = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
    ?: error("Cannot create MP4")
   try {
    context.contentResolver.openOutputStream(target)!!.use { output -> temp.inputStream().use { it.copyTo(output) } }
    context.contentResolver.update(target, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
    return target
   } catch (e: Exception) { context.contentResolver.delete(target, null, null); throw e }
  } finally {
   try { muxer?.release() } catch (_: Exception) {}
   extractor.release()
   temp.delete()
  }
 }
 fun download(source: String, referer: String, callback: (String) -> Unit) {
  executor.execute {
   var uri: android.net.Uri? = null
   val id = System.currentTimeMillis().toString()
   val name = "VRBrowser_${id}.ts"
   var downloadedBytes = 0L
   TransferStore.update(context, id, name, "Подготовка", 0, 0)
   try {
    var url = URL(source)
    var content = playlist(url, referer)
    repeat(3) {
     if (content.contains("#EXT-X-STREAM-INF")) {
      val lines = content.lines()
      val variants = lines.indices.filter { lines[it].startsWith("#EXT-X-STREAM-INF") && it + 1 < lines.size }
      val next = variants.lastOrNull()?.let { lines[it + 1].trim() } ?: error("Нет варианта потока")
      url = URL(url, next); content = playlist(url, referer)
     }
    }
    check(!content.contains("#EXT-X-STREAM-INF")) { "Слишком много вложенных плейлистов" }
    check(content.contains("#EXT-X-ENDLIST")) { "Прямой эфир не поддерживается" }
    check(!content.contains("#EXT-X-KEY") && !content.contains("#EXT-X-SESSION-KEY")) { "Шифрованные потоки не поддерживаются" }
    check(!content.contains("#EXT-X-MAP") && !content.contains("#EXT-X-BYTERANGE")) { "Этот формат HLS пока не поддерживается" }
    val segments = content.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }
    check(segments.isNotEmpty() && segments.size <= 10000) { "Некорректное число сегментов" }
    check(segments.all { URL(url, it).path.lowercase().endsWith(".ts") }) { "Поддерживаются только MPEG-TS сегменты" }
    val values = ContentValues().apply {
     put(MediaStore.Downloads.DISPLAY_NAME, name)
     put(MediaStore.Downloads.MIME_TYPE, "video/mp2t")
     put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/VRBrowser")
     put(MediaStore.Downloads.IS_PENDING, 1)
    }
    check(Build.VERSION.SDK_INT >= 29) { "Для сохранения требуется Android 10 или новее" }
    uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
     ?: error("Не удалось создать файл")
    context.contentResolver.openOutputStream(uri!!)?.use { output ->
     segments.forEachIndexed { index, segment ->
      val c = connect(URL(url, segment), referer)
      try {
       check(c.responseCode == 200) { "Сегмент ${index + 1}: HTTP ${c.responseCode}" }
       c.inputStream.use { input ->
        val buffer = ByteArray(32768)
        while (true) {
         val n = input.read(buffer)
         if (n < 0) break
         output.write(buffer, 0, n)
         downloadedBytes += n
        }
       }
      } finally { c.disconnect() }
      val progress = ((index + 1) * 100 / segments.size)
      TransferStore.update(context, id, name, "Загрузка", progress, downloadedBytes)
      if ((index + 1) % 25 == 0) notify(callback, "HLS: $progress% · ${index + 1}/${segments.size} сегментов")
     }
    } ?: error("Не удалось открыть файл")
    context.contentResolver.update(uri!!, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
    // Preserve the original MPEG-TS byte stream. Previous MP4 remuxing passed
    // track checks yet produced silent playback on real Huawei devices.
    // Do not claim MP4 support until audio playback is reliably verified.
    val finalUri = uri!!
    val finalName = name
    TransferStore.update(context, id, finalName, "Готово", 100, downloadedBytes, finalUri.toString())
    notify(callback, "Сохранено в Загрузки/VRBrowser: $finalName")
   } catch (e: Exception) {
    if (uri != null) context.contentResolver.delete(uri!!, null, null)
    TransferStore.update(context, id, name, "Ошибка: ${e.message ?: e.javaClass.simpleName}", 0, downloadedBytes)
    notify(callback, "Ошибка HLS: ${e.message ?: e.javaClass.simpleName}")
   }
  }
 }
}
